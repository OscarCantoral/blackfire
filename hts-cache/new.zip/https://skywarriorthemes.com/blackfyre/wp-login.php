<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Blackfyre &#8212; WordPress</title>
		<script type="text/javascript">function theChampLoadEvent(e){var t=window.onload;if(typeof window.onload!="function"){window.onload=e}else{window.onload=function(){t();e()}}}</script>
		<script type="text/javascript">var theChampDefaultLang = 'en_US', theChampCloseIconPath = 'https://skywarriorthemes.com/blackfyre/wp-content/plugins/super-socializer/images/close.png';</script>
		<script> var theChampSiteUrl = 'https://skywarriorthemes.com/blackfyre', theChampVerified = 0, theChampEmailPopup = 0; </script>
			<script> var theChampFBKey = '', theChampFBLang = 'en_US', theChampFbLikeMycred = 0, theChampSsga = 0, theChampCommentNotification = 0, theChampHeateorFcmRecentComments = 0, theChampFbIosLogin = 0; </script>
			<style type="text/css">.the_champ_horizontal_sharing .theChampSharing{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_horizontal_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_horizontal_sharing .theChampSharing:hover{
				border-color: transparent;
	}
	.the_champ_vertical_sharing .theChampSharing{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_vertical_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_vertical_sharing .theChampSharing:hover{
				border-color: transparent;
	}
	@media screen and (max-width:783px){.the_champ_vertical_sharing{display:none!important}}div.heateor_ss_mobile_footer{display:none;}@media screen and (max-width:783px){i.theChampTCBackground{background-color:white!important}div.the_champ_bottom_sharing{width:100%!important;left:0!important;}div.the_champ_bottom_sharing li{width:12.5% !important;}div.the_champ_bottom_sharing .theChampSharing{width: 100% !important;}div.the_champ_bottom_sharing div.theChampTotalShareCount{font-size:1em!important;line-height:28px!important}div.the_champ_bottom_sharing div.theChampTotalShareText{font-size:.7em!important;line-height:0px!important}div.heateor_ss_mobile_footer{display:block;height:40px;}.the_champ_bottom_sharing{padding:0!important;display:block!important;width: auto!important;bottom:-2px!important;top: auto!important;}.the_champ_bottom_sharing .the_champ_square_count{line-height: inherit;}.the_champ_bottom_sharing .theChampSharingArrow{display:none;}.the_champ_bottom_sharing .theChampTCBackground{margin-right: 1.1em !important}}</style>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-content/themes/blackfyre/addons/clan-wars/js/jquery.cookie.pack.js?ver=1.5.5'></script>
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-content/themes/blackfyre/addons/clan-wars/js/tabs.js?ver=1.5.5'></script>
<link rel='stylesheet' id='dashicons-css'  href='https://skywarriorthemes.com/blackfyre/wp-includes/css/dashicons.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://skywarriorthemes.com/blackfyre/wp-includes/css/buttons.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://skywarriorthemes.com/blackfyre/wp-admin/css/forms.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://skywarriorthemes.com/blackfyre/wp-admin/css/l10n.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://skywarriorthemes.com/blackfyre/wp-admin/css/login.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='the_champ_frontend_css-css'  href='https://skywarriorthemes.com/blackfyre/wp-content/plugins/super-socializer/css/front.css?ver=7.12.37' type='text/css' media='all' />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//skywarriorthemes.com/blackfyre/?wordfence_lh=1&hid=686C922183AC7CDB8F22422C5967457A');
</script>	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="https://skywarriorthemes.com/blackfyre/wp-content/uploads/2015/02/cropped-logo-helmet-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://skywarriorthemes.com/blackfyre/wp-content/uploads/2015/02/cropped-logo-helmet-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://skywarriorthemes.com/blackfyre/wp-content/uploads/2015/02/cropped-logo-helmet-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://skywarriorthemes.com/blackfyre/wp-content/uploads/2015/02/cropped-logo-helmet-270x270.jpg" />
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
	<form name="loginform" id="loginform" action="https://skywarriorthemes.com/blackfyre/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
					<style type="text/css" media="screen">
				.login-action-login #loginform,
				.login-action-lostpassword #lostpasswordform,
				.login-action-register #registerform {
					width: 302px !important;
				}
				#login_error,
				.message {
					width: 322px !important;
				}
				.login-action-login #loginform .gglcptch,
				.login-action-lostpassword #lostpasswordform .gglcptch,
				.login-action-register #registerform .gglcptch {
					margin-bottom: 10px;
				}
			</style>
		<div class="gglcptch gglcptch_v2"><div id="gglcptch_recaptcha_695765519" class="gglcptch_recaptcha"></div>
				<noscript>
					<div style="width: 302px;">
						<div style="width: 302px; height: 422px; position: relative;">
							<div style="width: 302px; height: 422px; position: absolute;">
								<iframe src="https://www.google.com/recaptcha/api/fallback?k=6Le4e0EUAAAAAKN0UC4elmmcdL4N-CVuVPE5MFF-" frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;"></iframe>
							</div>
						</div>
						<div style="border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px; height: 60px; width: 300px;">
							<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px !important; height: 40px !important; border: 1px solid #c1c1c1 !important; margin: 10px 25px !important; padding: 0px !important; resize: none !important;"></textarea>
						</div>
					</div>
				</noscript></div>	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
				<input type="hidden" name="redirect_to" value="https://skywarriorthemes.com/blackfyre" />
					<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>

			<p id="nav">
			<a href="https://skywarriorthemes.com/blackfyre/user-registration/">Register</a> | 		<a href="https://skywarriorthemes.com/blackfyre/my-account/lost-password/">Lost your password?</a>
				</p>
	
	<script type="text/javascript">
	function wp_attempt_focus(){
	setTimeout( function(){ try{
			d = document.getElementById('user_login');
				d.focus();
	d.select();
	} catch(e){}
	}, 200);
	}

			wp_attempt_focus();
			if(typeof wpOnload=='function')wpOnload();
			</script>

			<p id="backtoblog"><a href="https://skywarriorthemes.com/blackfyre/">
		&larr; Back to Blackfyre	</a></p>
			
	</div>

	
			<script type="text/javascript">
			var wc_product_block_data = JSON.parse( decodeURIComponent( '%7B%22min_columns%22%3A1%2C%22max_columns%22%3A6%2C%22default_columns%22%3A3%2C%22min_rows%22%3A1%2C%22max_rows%22%3A6%2C%22default_rows%22%3A1%2C%22thumbnail_size%22%3A300%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder.png%22%2C%22min_height%22%3A500%2C%22default_height%22%3A500%2C%22isLargeCatalog%22%3Afalse%2C%22limitTags%22%3Afalse%2C%22hasTags%22%3Afalse%2C%22productCategories%22%3A%5B%7B%22term_id%22%3A109%2C%22name%22%3A%22Uncategorized%22%2C%22slug%22%3A%22uncategorized%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A109%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Funcategorized%5C%2F%22%7D%2C%7B%22term_id%22%3A15%2C%22name%22%3A%22Albums%22%2C%22slug%22%3A%22albums%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A15%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A11%2C%22count%22%3A4%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fmusic%5C%2Falbums%5C%2F%22%7D%2C%7B%22term_id%22%3A9%2C%22name%22%3A%22Clothing%22%2C%22slug%22%3A%22clothing%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A9%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A12%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fclothing%5C%2F%22%7D%2C%7B%22term_id%22%3A10%2C%22name%22%3A%22Hoodies%22%2C%22slug%22%3A%22hoodies%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A10%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A9%2C%22count%22%3A6%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fclothing%5C%2Fhoodies%5C%2F%22%7D%2C%7B%22term_id%22%3A11%2C%22name%22%3A%22Music%22%2C%22slug%22%3A%22music%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A11%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A6%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fmusic%5C%2F%22%7D%2C%7B%22term_id%22%3A12%2C%22name%22%3A%22Posters%22%2C%22slug%22%3A%22posters%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A12%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A5%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fposters%5C%2F%22%7D%2C%7B%22term_id%22%3A13%2C%22name%22%3A%22Singles%22%2C%22slug%22%3A%22singles%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A13%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A11%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fmusic%5C%2Fsingles%5C%2F%22%7D%2C%7B%22term_id%22%3A14%2C%22name%22%3A%22T-shirts%22%2C%22slug%22%3A%22t-shirts%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A14%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A9%2C%22count%22%3A6%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2Fproduct-category%5C%2Fclothing%5C%2Ft-shirts%5C%2F%22%7D%5D%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fskywarriorthemes.com%5C%2Fblackfyre%5C%2F%22%7D' ) );
		</script>
		<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-content/plugins/super-socializer/js/front/social_login/general.js?ver=7.12.37'></script>
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-content/plugins/super-socializer/js/front/facebook/sdk.js?ver=7.12.37'></script>
<script type='text/javascript' data-cfasync="false" async="async" defer="defer" src='https://www.google.com/recaptcha/api.js?render=explicit&#038;ver=1.52'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var gglcptch = {"options":{"version":"v2","sitekey":"6Le4e0EUAAAAAKN0UC4elmmcdL4N-CVuVPE5MFF-","theme":"light","error":"<strong>Warning<\/strong>:&nbsp;More than one reCAPTCHA has been found in the current form. Please remove all unnecessary reCAPTCHA fields to make it work properly.","disable":0},"vars":{"visibility":true}};
/* ]]> */
</script>
<script type='text/javascript' src='https://skywarriorthemes.com/blackfyre/wp-content/plugins/google-captcha/js/script.js?ver=1.52'></script>
	<div class="clear"></div>
	</body>
	</html>
	